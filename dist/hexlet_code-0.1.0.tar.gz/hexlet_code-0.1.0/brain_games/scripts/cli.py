import prompt


def welcome_user():
    name = prompt.string('Greetings, mysterious stranger, what is your name?')
    print(f'Welcome to the Brain Games {name}! Mu-ha-ha!\
            \nThere is no way out of here. Literally.')
