#!/usr/bin/env python3
from cli import name


def main():
    name()


if __name__ == "__main__":
    main()
